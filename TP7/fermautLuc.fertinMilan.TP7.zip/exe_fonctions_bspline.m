T1=([0, 1, 2, 3, 4]);
%(a) l'allure des courbes est identique mais il y en a deux dans l'ordre 2 et une seule dans l'ordre 3

T2=([0,0,0,1,2,3,3,3]);
%(b)

T3=([0,0,0,1,1,1]);
%(c) on retrouve le polynome de bernstein

fonctions_bsplines(2, T3); %fonctions_bslines(m, Tableau des point Tn)